if __name__ == '__main__':
    array = []
    inicio = -1.5

    for i in range(10):   
        numero = inicio + (i * 0.5)
        array.append(numero)

    for x in array:
            print(x)