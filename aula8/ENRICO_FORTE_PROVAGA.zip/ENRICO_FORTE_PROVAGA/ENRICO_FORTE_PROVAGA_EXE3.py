def somaTres(quant):
    string= ""
    soma = 0
    for i in range(0,quant):
        string += "3"
        string = int(string)

        soma += string
        soma = str(soma)

        string = str(string)
        soma = int(soma)

    print(f"A soma da sequência de números compostos por {quant}, indo até 5 dígitos é: {soma}")

if __name__ == '__main__':
    num = int(input("Insira um numero positivo: "))

    somaTres(num)